import time
import sys

def simple_loading_bar(iterations):
    for i in range(iterations):
        time.sleep(0.1)  # Simulating some work
        sys.stdout.write(f"\rLoading: [{'#' * (i + 1)}{'.' * (iterations - i - 1)}] {int((i + 1) / iterations * 100)}%")
        sys.stdout.flush()
    print()  # Move to the next line after completion

# Example usage
simple_loading_bar(30)
